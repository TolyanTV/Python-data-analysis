import pandas as pd

#1
data_set = pd.read_csv("FIFA.csv", sep = ',')

#2
data_set1 = data_set.groupby('Year')
print(data_set1.agg({'Year':['count']}))

#3
print(data_set[data_set['Year'] == 2014][['Datetime','City']])

#4
data_set.insert(loc=8,column='Goals_count',value=data_set[['Home.Team.Goals','Away.Team.Goals']].sum(axis=1))
print(data_set[['Datetime','Home.Team.Name','Away.Team.Name','Goals_count']])

#5
print(data_set1.agg({'Goals_count':['sum','max','min']}))

#6
print(data_set.groupby(['City','Stadium']).agg({'Stadium':['count']}))

#7
print(data_set1.agg({'Goals_count':['mean']}))

#8
data_set2 = data_set1.agg({'Goals_count':['sum']})
data_set2.columns = ['sum']
print(data_set2[data_set2['sum'] > 150])