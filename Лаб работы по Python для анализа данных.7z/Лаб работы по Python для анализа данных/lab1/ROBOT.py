n, m = map(int, input("Размеры комнаты (N M): ").split())
x, y = map(int, input("Начальное положение РОБОТА (x y): ").split())

def robot_move(x, y, command):
    if command == 'N' and x < n:
        x += 1
    elif command == 'S' and x > 1:
        x -= 1
    elif command == 'W' and y > 1:
        y -= 1
    elif command == 'E' and y < m:
        y += 1

    return x, y

#file_name = input("Введите имя файла с командами: ")

file_name= open("commands.txt", "r")
commands = file_name.read()
file_name.close()

for command in commands:
    if command == "X":
        break

    x, y = robot_move(x, y, command)
    print(f"Марсоход находится на позиции {x}, {y}")
