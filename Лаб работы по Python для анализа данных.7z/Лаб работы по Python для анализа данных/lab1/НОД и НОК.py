def NOD(a, b):
    while (a != 0 and b != 0):
        if a >= b:
            a %= b
        else:
            b %= a
    return a or b

def NOK(a, b):
    return a * b // (NOD(a, b))

N = int(input('Введите количество участников команды A: '))
M = int(input('Введите количество участников команды B: '))

d = NOK(N, M)

print('Наименьшее число d =', d)

