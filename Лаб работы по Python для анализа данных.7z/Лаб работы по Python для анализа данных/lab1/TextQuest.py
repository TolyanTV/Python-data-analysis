room = 'коридор'

while room != 'улица':
    if room == 'коридор':
        print('Вы в коридоре. Куда идем?')
        print('1 - в спальню')
        print('2 - в ванную')
        print('3 - на кухню')
        print('4 - в дверь')

        move = input()

        if move == '1':
            room = 'спальня'
        elif move == '2':
            room = 'ванная'
        elif move == '3':
            room = 'кухня'
        elif move == '4':
            print('Вы выбрались на улицу. Поздравляем, вы выиграли!')
            break
        else:
            print('Неправильный выбор. Попробуйте еще раз.')
            break

    elif room == 'спальня':
        print('Вы  в спальне. Куда идем?')
        print("1 - в ванную")
        print("2 -в коридор")

        move = input()

        if move == '1':
            room = 'ванная'
        elif move == '2':
            room = 'коридор'
        else:
            print('Неправильный выбор. Попробуйте еще раз.')

    elif room == 'ванная':
        print('Вы в ванной. Куда идем?')
        print("1 - в коридор")
        print("2 - в спальню")

        move = input()

        if move == '1':
            room = 'коридор'
        elif move == '2':
            room = 'спальня'
        else:
            print('Неправильный выбор. Попробуйте еще раз.')

    elif room == 'кухня':
        print('Вы на кухне. Окно открыто. Куда идем?')
        print('1 - в коридор')
        print('2 - в окно')

        move = input()

        if move == '1':
            room = 'коридор'
        elif move == '2':
            room = 'окно'
        else:
            print('Неправильный выбор. Попробуйте еще раз.')

    elif room == 'окно':
        print('Поздравляю вы выиграли премию Дарвина!')
        break

print('Спасибо за игру!')
