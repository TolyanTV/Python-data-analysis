import random

name = input('Введите свое имя:', )
print('Здравствуй', name + '! Сыграем в угадайку.')

searchNumber = random.randint(1, 100)

while True:

    i = input("Введите число:")

    if i.isdigit(): #Проверка на целое число
        i = int(i)
    else:
        print("Пожалуйста, введите целое число.")
        continue

    if (searchNumber == i):
        print('Поздравляю <3! Вы угадали число. Это:', i)
        break
    elif (searchNumber > i):
        print('Число', i, 'меньше искомого, попробйте снова.')
    elif (searchNumber < i):
        print('Число', i, 'больше искомого, попробуй снова.')
    if (i < 1 or i > 100):
        print('Неверный ввод!')
        continue