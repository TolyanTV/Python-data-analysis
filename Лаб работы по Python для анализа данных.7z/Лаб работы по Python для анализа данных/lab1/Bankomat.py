def bankomat(summ, banknotes):
    if summ < 0:
        return None

    count_5000 = summ // 5000
    summ %= 5000

    count_1000 = summ // 1000
    summ %= 1000

    count_500 = summ // 500
    summ %= 500

    count_200 = summ // 200
    summ %= 200

    count_100 = summ // 100
    summ %= 100

    if summ == 0:
        return count_5000, count_1000, count_500, count_200, count_100
    else:
        return None


banknotes = [5000, 1000, 500, 200, 100]
summ = int(input("Введите сумму для снятия: "))
result = bankomat(summ, banknotes)

if result is None:
    print("Невозможно выдать данную сумму.")
else:
    with open("withdrawal_details.txt", "w") as file:
        file.write("Выданная сумма: {}\n".format(summ))
        file.write("Купюры:\n")
        for i in range(len(banknotes)):
            file.write("{} рублей: {}\n".format(banknotes[i], result[i]))

