import math
def nok(a, b):
    return math.gcd(a, b)

def sum(a, b, c, d):
    n = b*d//nok(b,d) #400
    ch = a * (n // b) + c * (n // d) #500
    return ch//(nok(ch, n)), n//(nok(ch, n))

k = int(input('Количество дробей: '))
x = int(input('Числитель 1: '))
y = int(input('Знаменатель 1: '))
for i in range(k-1, k+1):
    xi = int(input(f'Числитель: {i}: '))
    yi = int(input(f'Знаменатель: {i}: '))
    x, y = sum(x, y, xi, yi)

if x > y:
    print('Ответ: {} {}/{}'.format(x//y, x%y, y))
else:
    print('Ответ: {}/{}'.format(x, y))