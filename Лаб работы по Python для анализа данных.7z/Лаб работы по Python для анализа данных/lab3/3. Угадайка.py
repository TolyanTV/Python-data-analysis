# Запрашиваем максимальное число, которое мог загадать Иван
N = int(input("Введите максимальное число: "))

# Создаем множество возможных чисел, которые мог загадать Иван
possible_numbers = set(range(1, N + 1))

while True:
    # Запрашиваем числа, которые назвал Сергей
    input_str = input("Нужное число есть среди вот этих чисел: ")

    # Если Сергей попросил помощи, завершаем игру
    if input_str == "Помогите!":
        break

    # Разбиваем введенные числа на список
    guessed_numbers = input_str.split()

    # Создаем множество из угаданных чисел
    guessed_numbers_set = set(map(int, guessed_numbers))

    # Проверяем, есть ли угаданные числа в множестве возможных чисел
    if guessed_numbers_set.issubset(possible_numbers):
        answer = "Да"
        possible_numbers &= guessed_numbers_set  # Обновляем множество возможных чисел
    else:
        answer = "Нет"

    print("Ответ Ивана:", answer)

# Выводим числа, которые мог загадать Иван
print("Иван мог загадать следующие числа:", " ".join(map(str, possible_numbers)))
