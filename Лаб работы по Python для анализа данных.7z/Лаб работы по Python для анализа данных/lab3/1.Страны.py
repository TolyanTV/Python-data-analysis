#Вводится количество стран
k = int(input("Кол-во стран: "))

# Создаем словарь для хранения информации о странах и городах
countries = {}

# Вводим информацию о странах и городах
for i in range(k):
    country_data = input(f"{i + 1} страна: ").split()
    country = country_data[0]
    cities = country_data[1:]
    countries[country] = cities

# Запрашиваем названия городов
for i in range(k * 3):
    city_name = input(f"{i + 1} город: ")

    # Ищем город в словаре стран
    found = False
    for country, cities in countries.items():
        if city_name in cities:
            print(f"Город {city_name} расположен в стране {country}.\n")
            found = True
            break

    # Если город не найден, выводим сообщение
    if not found:
        print(f"По городу {city_name} данных нет.\n")