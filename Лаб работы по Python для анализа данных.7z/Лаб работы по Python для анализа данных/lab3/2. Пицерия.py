from collections import OrderedDict

# Запрашиваем количество заказов
N = int(input("Введите кол-во заказов: "))

# Создаем упорядоченный словарь для хранения информации о заказах
orders = OrderedDict()

# Вводим информацию о заказах
for i in range(N):
    order_data = input(f"{i + 1} заказ: ").split()
    customer = order_data[0]
    pizza = order_data[1]
    quantity = int(order_data[2])

    # Проверяем, есть ли уже заказы от этого покупателя
    if customer in orders:
        if pizza in orders[customer]:
            orders[customer][pizza] += quantity
        else:
            orders[customer][pizza] = quantity
    else:
        orders[customer] = {pizza: quantity}

# Сортируем упорядоченный словарь по ключам (покупателям) и для каждого внутреннего словаря (видам пицц) также сортируем по ключам
sorted_orders = OrderedDict(sorted(orders.items()))
for customer, customer_orders in sorted_orders.items():
    sorted_customer_orders = OrderedDict(sorted(customer_orders.items()))
    print(customer + ":")
    for pizza, quantity in sorted_customer_orders.items():
        print(f"{pizza}: {quantity}")
