# Запрашиваем количество человек
N = int(input("Введите количество человек: "))

# Создаем словарь для хранения родственных связей
family_tree = {}

# Вводим родственные связи
for i in range(N - 1):
    child, parent = input(f"{i + 1} пара: ").split()
    family_tree[child] = parent

# Добавляем начального человека (Peter_I) с высотой 0
family_tree["Peter_I"] = None

# Создаем словарь для хранения высот каждого человека
heights = {}

# Функция для вычисления высоты человека
def calculate_height(person):
    if person not in heights:
        parent = family_tree.get(person)
        if parent is None:
            heights[person] = 0
        else:
            heights[person] = calculate_height(parent) + 1
    return heights[person]

# Вычисляем высоту каждого человека
for person in family_tree:
    calculate_height(person)

# Сортируем и выводим имена и высоты в лексикографическом порядке
sorted_people = sorted(family_tree.keys())
for person in sorted_people:
    print(f"{person} {heights[person]}")
