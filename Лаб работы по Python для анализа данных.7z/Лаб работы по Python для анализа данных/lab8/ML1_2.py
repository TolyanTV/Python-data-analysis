import pandas as pd
import numpy as np

np.random.seed(242)

tr_mcc_codes = pd.read_csv('data/tr_mcc_codes.csv', sep=';')
tr_types = pd.read_csv('data/tr_types.csv', sep=';')
transactions = pd.read_csv('data/transactions.csv', sep=',', nrows=1000000)
gender_train = pd.read_csv('data/gender_train.csv', sep=';')

# Задание 1
sample_tr_types = tr_types.sample(100)
print(sample_tr_types)

# Нахождение доли наблюдений, содержащих подстроку 'плата'
filtered_rows = sample_tr_types['tr_description'].str.lower().str.contains('плата')
fraction_with_pлата = filtered_rows.sum() / len(filtered_rows)

# Вывод результата
print(f"{fraction_with_pлата:.2f}")