import pandas as pd
import matplotlib.pyplot as plt
colors = ['b', 'r', 'g', 'y']

# 1
table = pd.read_csv('Billionaires.csv', sep=',')
print(table[:100])

# 2
print(table[table.notna().sum().sort_values().index].info())
# 4 столбца с наибольшим количеством пропусков: organization, title, residenceStateRegion, state
table.drop(columns=['organization', 'title', 'residenceStateRegion', 'state'], axis=1, inplace=True)

# 3
summ = table['finalWorth'].sum()
print('Cуммарный капитал всех миллиардеров:', summ)

# 4
count_billionaires = table.groupby('country').agg({'personName': 'count'})
count_billionaires.columns = ['Count']
print(count_billionaires)

# 5
print(count_billionaires.sort_values(by='Count', ascending=False)[:10].plot(kind='bar', title='Количество миллиардеров в десяти странах с их наибольшим количеством', color=colors))
plt.show()

# 6
print(table[((table['country'] == 'United States') | (table['country'] == 'China')) & (table['age'] > 70)][['personName', 'age', 'country']])

# 7
print(table[table['country'] == 'Russia']['personName'])

table2 = table.copy()
table2.loc[table2['country'] != 'Russia', 'country'] = 'others'
table2.groupby('country').agg({'finalWorth': 'sum'}).plot(kind='pie', autopct='%1.2f%%', title='Процентное соотношение капиталов русских миллиардеров к суммарному капиталу', colors=colors, subplots=True, startangle=30)
plt.show()

# 10
table2.groupby('age').agg({'personName': 'count'}).plot(kind='hist', color=colors[0])
plt.show()
