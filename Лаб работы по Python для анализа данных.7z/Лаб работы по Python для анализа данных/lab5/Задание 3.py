import pandas as pd
import numpy as np

# Создать объект Series с пустыми значениями
series_data = pd.Series([1, 2, np.NaN, 3, 4, np.NaN, 7, 8, np.NaN, 10])

# Шаг 1: Вывести на экран только непустые значения
non_nan_values = series_data.dropna()
print("Непустые значения:")
print(non_nan_values)

# Шаг 2: Извлечь квадратный корень из каждого элемента и вывести на экран результат
sqrt_values = np.sqrt(series_data)
print("\nКвадратный корень из каждого элемента:")
print(sqrt_values)

# Шаг 3: С помощью маски заменить все пустые значения на -1 и вывести на экран результат
masked_values = series_data.fillna(-1)
print("\nРезультат после замены пустых значений на -1:")
print(masked_values)
