import numpy as np
import pandas as pd

# Шаг 1: Сгенерировать случайным образом массив numpy из 20 элементов в диапазоне от 1 до 100
random_array = np.random.randint(1, 101, 20)

# Шаг 2: Преобразовать его в объект Series и вывести его на экран
series_data = pd.Series(random_array)
print("Исходный объект Series:")
print(series_data)

# Шаг 3: Вывести элементы с номерами от 5 до 10 включительно
print("\nЭлементы с номерами от 5 до 10 включительно:")
print(series_data[5:11])

# Шаг 4: Вывести элементы со значениями от 10 до 50 включительно
print("\nЭлементы со значениями от 10 до 50 включительно:")
print(series_data[(series_data >= 10) & (series_data <= 50)])

# Шаг 5: Ввести с клавиатуры 3 целых числа и вывести из объекта Series индексы всех элементов с заданными значениями
input_values = [int(input("Введите число: ")) for _ in range(3)]
indices_with_values = series_data[series_data.isin(input_values)].index
print(f"\nИндексы элементов с заданными значениями {input_values}:")
print(indices_with_values)

# Шаг 6: Вывести только четные элементы объекта Series (использовать лямбда-функцию)
even_elements = series_data[lambda x: x % 2 == 0]
print("\nЧетные элементы объекта Series:")
print(even_elements)

# Шаг 7: Заменить все элементы, значение которых больше 70, на 0 и вывести результат на экран
series_data[series_data > 70] = 0
print("\nРезультат после замены элементов больше 70 на 0:")
print(series_data)
