import pandas as pd

# Шаг 1: Прочитать данные из файла a.txt и преобразовать их в словарь
# Предположим, что файл содержит данные в формате "фамилия класс"
with open('a.txt', 'r') as file:
    lines = file.readlines()
    data_dict = {line.split()[0].strip(): int(line.split()[1].strip()) for line in lines}

# Шаг 2: Занести данные из словаря в объект Series
series_data = pd.Series(data_dict)

# Шаг 3: Вывести данные на экран
print("Исходные данные:")
print(series_data)

# Шаг 4: Отобразить столбиком только фамилии учеников 8 класса
print("\nФамилии учеников 8 класса:")
print(series_data[series_data == 8].index)

# Шаг 5: "Перевести" всех учеников в следующий класс и вывести данные на экран
series_data += 1
print("\nДанные после перевода в следующий класс:")
print(series_data)

# Шаг 6: Посчитать количество учеников в каждом классе и вывести данные на экран
class_counts = series_data.value_counts()
print("\nКоличество учеников в каждом классе:")
print(class_counts)

# Шаг 7: Вывести информацию об учениках с фамилиями Авдеев и Леонов
print("\nИнформация об учениках с фамилиями Авдеев и Леонов:")
print(series_data[series_data.index.isin(['Avdeev', 'Leonov'])])
