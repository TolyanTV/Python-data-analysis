import random
from random import randint
import math

list1 = [random.randint(-20, 20) for i in range(20)]
print(list1)

list2 = [i * 2 if i < 0 else math.sqrt(i) for i in list1]
print(list2)

list3 = []
for i in list2:
    if (i < 0):
        list3.append(0)
    list3.append(i)
print(list3)

K = int(input("Введите значение K: "))
list4 = [i for i in list3 if i != K]
print(list4)

Z = int(input("Введите значение Z: "))
list5 = [0, 0, 0] + list4 + [Z, Z, Z]
print(list5)

list5.sort()
print(list5)