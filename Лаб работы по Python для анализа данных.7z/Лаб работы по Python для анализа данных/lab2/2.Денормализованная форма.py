def format_denormalize(s):
    if s[0] == '0':
        index = 2
        if s[index] != '0' and len(s) == index + 1:
            return s[index] + s[index + 1:] + f' * 10 ** -{index - 1}'
        else:
            while s[index] == '0':
                index += 1
            return  s[index] + '.' + s[index + 1:] + f' * 10 ** -{index - 1}'
    else:
        index = s.find('.')
        s = s.replace('.', '')
        return s[0] + '.' + s[1:] + f' * 10 ** {index - 1}'

number = input("Введите число: ")
formatted_number = format_denormalize(number)
print(f'Формат плавающей точки: x = {formatted_number}')
