# Ввод количества друзей и долговых расписок
N = 2
K = int(input("Введите количество долговых расписок: "))

# Создание списков для отслеживания балансов и номеров друзей
balances = [0] * N
friend_numbers = list(range(1, N + 1))

# Ввод долговых расписок и обновление баланса
for _ in range(K):
    borrower = int(input("Кому: ")) - 1
    lender = int(input("От кого: ")) - 1
    amount = int(input("Сколько: "))

    # Увеличение баланса должника и уменьшение баланса кредитора
    balances[borrower] -= amount
    balances[lender] += amount

# Вывод баланса друзей
print("Баланс друзей:")
for friend, balance in zip(friend_numbers, balances):
    print(f"{friend} : {balance}")