import pandas as pd
import matplotlib.pyplot as plt

table = pd.read_csv('vgsale_1.csv', sep=',').drop_duplicates(['Name', 'Year'])
colors = ['b', 'r', 'g', 'y']

# 1
game_2000 = table[table['Year'] <= 2000].groupby('Genre').agg({'Name' : 'count'})
game_2000.columns = ['Number']
game_2000['Sum'] = game_2000['Number']
game_2000.sort_values(by='Sum', ascending=False)[['Number']].plot(kind='bar', stacked=True, title='Популярность жанров до 2000 года', color=colors)
plt.show()

game_2000 = table[table['Year'] <= 2000].groupby('Genre').agg({'Global_Sales' : 'sum'})
game_2000.columns = ['Global_Sales']
game_2000['Sum'] = game_2000['Global_Sales']
game_2000.sort_values(by='Sum', ascending=False)[['Global_Sales']].plot(kind='bar', stacked=True, title='Популярность жанров до 2000 года', color=colors[1])
plt.show()

game_2020 = table[table['Year'] > 2000].groupby('Genre').agg({'Name' : 'count'})
game_2020.columns = ['Number']
game_2020['Sum'] = game_2020['Number']
game_2020.sort_values(by='Sum', ascending=False)[['Number']].plot(kind='bar', stacked=True, title='Популярность жанров после 2000 года', color=colors)
plt.show()

game_2020 = table[table['Year'] > 2000].groupby('Genre').agg({'Global_Sales' : 'sum'})
game_2020.columns = ['Global_Sales']
game_2020['Sum'] = game_2020['Global_Sales']
game_2020.sort_values(by='Sum', ascending=False)[['Global_Sales']].plot(kind='bar', stacked=True, title='Популярность жанров после 2000 года', color=colors[1])
plt.show()


# 2
count_games = table.groupby('Year').count()['Name']
count_games.plot(color=colors[1])
plt.show()

# 3
top_publishers = table.groupby('Publisher').agg({'Name' : 'count'}).sort_values(by='Name', ascending=False).reset_index()['Publisher'][:3].to_list()
for i in range(3):
    table[(table['Publisher'] == top_publishers[i])].groupby('Platform').agg({'Name' : 'count'}).plot(kind='bar', stacked=True, color=colors)
plt.show()

# 4 1980-2000
table[(table['Year'] >= 1980) & (table['Year'] <= 2000)].agg({'Other_Sales' : 'sum', 'NA_Sales' : 'sum', 'EU_Sales' : 'sum', 'JP_Sales' : 'sum'}).plot(kind='pie', autopct='%1.0f%%', title='Объем продаж за 1980 - 2000 года', colors=colors)
plt.show()

# 4 2001-2020
table[(table['Year'] >= 2001) & (table['Year'] <= 2020)].agg({'Other_Sales' : 'sum', 'NA_Sales' : 'sum', 'EU_Sales' : 'sum', 'JP_Sales' : 'sum'}).plot(kind='pie', autopct='%1.0f%%', title='Объем продаж за 2001 - 2020 года', colors=colors)
plt.show()