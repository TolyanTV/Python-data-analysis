import numpy as np

# Шаг 1: Генерация двух одномерных массивов m1 и m2
m1 = np.random.randint(1, 11, size=10)
m2 = np.random.randint(1, 11, size=10)
print("Массив m1:", m1)
print("Массив m2:", m2)

# Шаг 2: Формирование массива m3 с элементами, которые есть либо в m1, либо в m2
m3 = np.union1d(np.setdiff1d(m1, m2), np.setdiff1d(m2, m1))
print("\n1. Массив m3:", m3)

# Шаг 3: Замена значений в m1
m1[(m1 % 3 == 0) | (m1 % 2 == 0)] = 1
print("\n2. Массив m1 после замены:", m1)

# Шаг 4: Слияние m1 и m2 в один массив и преобразование в матрицу 4x5
m_array = np.concatenate([m1, m2]).reshape(4, 5)
print("\n3. Объединенная матрица 4x5:")
print(m_array)

# Шаг 5: Удаление 1 и 4 столбцов из матрицы
merged_array = np.delete(m_array, [0, 3], axis=1)
print("\nШаг 5: Матрица после удаления 1 и 4 столбцов:")
print(merged_array)

# Шаг 6: Транспонирование матрицы
transposed_matrix = np.transpose(merged_array)
print("\nШаг 6: Транспонированная матрица:")
print(transposed_matrix)


