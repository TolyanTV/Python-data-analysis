import numpy as np

# 1: Генерация случайной матрицы 8x8
matrix = np.random.randint(-10, 11, size=(8, 8))

# Вывод матрицы на экран
print("Исходная матрица:")
print(matrix)

# 2: Вывод центральной части матрицы 4x4
center_part = matrix[2:6, 2:6]
print("\nЦентральная часть матрицы 4x4:")
print(center_part)

# Шаг 4: Удаление строк с минимальным элементом
min_element = matrix.min()
matrix = matrix[~np.any(matrix == min_element, axis=1)]

print("\nМатрица после удаления строк:")
print(matrix)

# Шаг 5: Вставка строки с минимальным элементом перед первой строкой
min_row = np.full((1, matrix.shape[1]), min_element)
matrix = np.vstack([min_row, matrix])

print("\nМатрица после вставки строки:")
print(matrix)

# Шаг 6: Вычисление суммы и среднего арифметического всех элементов матрицы
sum_matrix = np.sum(matrix)
average_matrix = np.mean(matrix)

print("\nСумма всех элементов матрицы:", sum_matrix)
print("Среднее арифметическое всех элементов матрицы:", average_matrix)
