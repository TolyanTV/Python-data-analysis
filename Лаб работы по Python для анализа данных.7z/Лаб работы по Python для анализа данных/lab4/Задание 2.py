import numpy as np

# Вводим имена учеников с клавиатуры
names = np.array(input("Введите имена учеников, разделенные запятой: ").split(','))

# Вводим оценки учеников с клавиатуры
grades = []
for i in range(len(names)):
    grade_input = input(f"Введите оценки для {names[i]}, разделенные запятой: ")
    grades.append([int(x) for x in grade_input.split(',')])

grades = np.array(grades)

# Вводим имя для поиска
input_name = input("Введите имя ученика для поиска: ")

# Создаем маску для выбора строк с заданным именем
mask = names == input_name

# Выводим оценки учеников с заданным именем
if np.any(mask):
    print(f"Оценки учеников с именем '{input_name}':")
    print(grades[mask])
else:
    print(f"Ученика с именем '{input_name}' нет в списке.")
