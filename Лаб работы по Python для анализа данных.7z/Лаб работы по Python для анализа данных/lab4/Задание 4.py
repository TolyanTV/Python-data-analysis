import numpy as np

n = 3
A = np.array([[0.54, 0.25, 0.2],
             [0.3, 0.17, 0.1],
             [0.08, 0.06, 0.09]])

print('A:')
print(A)

col_sum = np.sum(A, axis=0)
mask_col = col_sum >= 1
A[:, mask_col] = 0

print('Сумма столбцов:')
print(col_sum)
print('A после замены :')
print(A)

det_A = np.linalg.det(A)
print('Определитель A =', det_A)

E = np.eye(n)
B = E - A
print('B = E - A :')
print(B)

C = np.linalg.inv(B)
print('C = B^(-1) :')
print(C)

Y = np.array([30, 17, 10])
X = np.dot(C, Y)
print('Y:')
print(Y)
print('X = C * Y :')
print(X)

print('A * X + Y = X :')
X = np.linalg.solve(E - A, Y)
print(X)






'''
A * X + Y = X
A * X - X = -Y
X * (A - E) = -Y
'''