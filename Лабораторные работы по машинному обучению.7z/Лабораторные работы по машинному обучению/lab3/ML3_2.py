import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics
from sklearn.linear_model import LassoCV
from sklearn.linear_model import RidgeCV

#1
data = pd.read_csv('house_price.csv')

#2
data = data.dropna(thresh=1000, axis=1).dropna()
print('Количество оставшихся строк и столбцов', data.shape)

#3
data = data.select_dtypes(exclude=['object'])
print('Количество оставшихся столбцов', data.shape[1])

#4
x = data.loc[:, data.columns != 'SalePrice']
y = data['SalePrice']
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

#5
print('Линейная регрессия')
model = LinearRegression()
model.fit(x_train, y_train)
print(model.coef_, model.intercept_)
y_pred = model.predict(x_test)
print(y_pred)

print('Линейная регрессия')
print('RMSE:', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))
print('R2:', np.round(metrics.r2_score(y_test, y_pred), 2))

#6
print('Lasso-регрессия')
lasso = LassoCV(alphas = [0.1, 1.0, 10], cv = 5)
lasso.fit(x_train, y_train)
print(lasso.coef_)
y_pred = lasso.predict(x_test)
print(y_pred)

print('Lasso-регрессия')
print(f'RMSE: {np.sqrt(metrics.mean_squared_error(y_test, y_pred))}')
print(f'R2: {np.round(metrics.r2_score(y_test, y_pred), 2)}')

#7
print('Ridge-регрессия (гребневая регрессия)')
ridge_cv = RidgeCV(alphas = [0.1, 1.0, 10], cv = 10)
ridge_cv.fit(x_train, y_train)
print(ridge_cv.coef_, ridge_cv.intercept_)
y_pred = ridge_cv.predict(x_test)
print(y_pred)

print('Ridge-регрессия (гребневая регрессия)')
print(f'RMSE: {np.sqrt(metrics.mean_squared_error(y_test, y_pred))}')
print(f'R2: {np.round(metrics.r2_score(y_test, y_pred), 2)}')