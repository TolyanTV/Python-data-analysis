import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics

#1
data = pd.read_csv('Life.csv')

#2
data.dropna(inplace=True)
data1 = data.drop(columns=['Country', 'Status'])

#3
table_corr = data1.corr()
print(table_corr)
plt.figure(figsize=(15, 15))
sns.heatmap(table_corr, annot=True)
plt.show()

#4
max_corr = table_corr['Life expectancy '].abs().sort_values().where(lambda x: x > 0.5).dropna()[:-1]
print("Набор данных, максимально коррелирующий с Life expectancy:")
print(max_corr)

#5
x = data[max_corr.index]
y = data['Life expectancy ']
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

#6
model = LinearRegression()
model.fit(x_train, y_train)
print(model.coef_, model.intercept_)
y_pred = model.predict(x_test)
print(y_pred)

print('RMSE:', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))
print('R2:', np.round(metrics.r2_score(y_test, y_pred), 2))