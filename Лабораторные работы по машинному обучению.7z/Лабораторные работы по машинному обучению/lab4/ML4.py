import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, classification_report
from sklearn.metrics import RocCurveDisplay

#1
data = pd.read_csv('heart.csv')
print(data.head(10))

#2
print(data.isnull().sum(), '\n')
data.dropna()

#3
print(data['target'].value_counts())
print('Классы сбалансированы')

#4
data1 = data[['age','trestbps', 'chol','thalach','target']]
sns.pairplot(data1, hue = 'target')
plt.show()

#5
plt.figure(figsize=(10, 10))
sns.heatmap(data.corr(), annot=True)
plt.show()

#6
X = data.drop('target', axis=1)
y = data['target']

#7
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=101)

#8
scaler = StandardScaler()
scaled_X_train = scaler.fit_transform(X_train)
scaled_X_test = scaler.transform(X_test)

#9
model = LogisticRegression()
model.fit(scaled_X_train, y_train)
y_pred = model.predict(scaled_X_test)

#10
print("\nКоэффициенты модели:")
print(model.coef_)

#11
#матрица ошибок (confusion matrix)
# передадим ей тестовые и прогнозные значения
model_matrix = confusion_matrix(y_test, y_pred, labels = [1,0])
# для удобства создадим датафрейм
model_matrix_df = pd.DataFrame(model_matrix)
print('Confusion Matrix Array:', model_matrix_df)

#Confusion Matrix Plot(ConfusionMatrixDisplay)
CMD = ConfusionMatrixDisplay(confusion_matrix = model_matrix)
CMD.plot()
plt.show()

# Classification Report
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

#12
roc = RocCurveDisplay.from_estimator(model, scaled_X_test, y_test)
roc.plot()
plt.show()

#13
patient = [ 64. ,   1. ,   1. , 142. , 286. ,   0. ,   0. , 136. ,   1. , 3.2,   1. ,   2. ,   1. ]
X_test.loc[len(X_test)] = patient
print("Новая строка в тестовом датасете X_test:")
print(X_test.tail(5))
patient_scaled = scaler.transform([patient])
prediction = model.predict(patient_scaled)[0]
print("\nПрогноз для нового пациента:", "У пациента сердечное заболевание" if prediction == 1 else "Пациент здоров")