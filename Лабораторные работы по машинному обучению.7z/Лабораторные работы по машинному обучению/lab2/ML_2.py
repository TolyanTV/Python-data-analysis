import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats
from statsmodels.stats.proportion import proportions_ztest
import seaborn as sns

# Задание 1
print('Задание 1')
data = pd.read_csv('heart.csv')
print(data)

count = data[data['target'] == 1]['target'].count()
nobs = data['target'].count()
print(proportions_ztest(count= count , nobs= nobs , value= 0.46, alternative='larger'))
p_value = 0.001561
print(f'p-value = {p_value} < 0.05, да')

# Задание 2
print('Задание 2')
mens = data[data['sex']== 1]['trestbps']
womens = data[data['sex'] == 0]['trestbps']
print(f'Отношение дисперсией = {max(np.var(mens), np.var(womens))/min(np.var(mens), np.var(womens))} -> можем предположить, что дисперсии равны.')

plt.hist(mens, label = 'Мужчины')
plt.show()
plt.hist(womens, label = 'Женщины')
plt.show()

rez = stats.ttest_ind(a=mens, b=womens, equal_var=True, alternative = 'less')
print(rez)

# Задание 3
print('Задание 3')
data3 = data[data['age'] > 60]['chol']
a = stats.ttest_1samp (data3, 250)
pvalue = 0.158762
print(f'p-value = {pvalue} -> новая гипотеза отвергается')

# Задание 4
print('Задание 4')
data4 = data['thalach']
print(stats.norm.interval(confidence = 0.95, loc = np.mean(data4), scale = stats.sem(data4)))

#Задание 5
print('Задание 5')
data5 = pd.read_csv('House.csv')
data5 = data5.dropna()
print(data5)
data_kol = data5[['PRICE','BEDS','BATH','PROPERTYSQFT', 'LATITUDE', 'LONGITUDE']]
table_corr = data_kol.corr()
print(table_corr)
plt.imshow(table_corr, cmap='hot')
plt.show()

#Задание 6
print('Задание 6')
#1 pair - {BEDS, BATH} = 0.749161
#2 pair - {PRICE, BATH} = 0.706548
#3 pair - {BATH, PROPERTYSQFT} = 0.562195
plt.scatter(x=data_kol['BEDS'], y=data_kol['BATH'])
plt.show()
plt.scatter(x=data_kol['PROPERTYSQFT'] , y=data_kol['BEDS'])
plt.show()
plt.scatter(x=data_kol['BATH'], y=data_kol['PROPERTYSQFT'])
plt.show()

#Задание 7
print('Задание 7')
Q1 = data_kol['PRICE'].quantile(q=.25)
Q3 = data_kol['PRICE'].quantile(q=.75)
IQR = data_kol['PRICE'].apply(stats.iqr)
data_kol = data_kol[~((data_kol['PRICE'] < (Q1-1.5*IQR)) | (data_kol['PRICE'] > (Q3+1.5*IQR)))]

Q1 = data_kol['PROPERTYSQFT'].quantile(q=.25)
Q3 = data_kol['PROPERTYSQFT'].quantile(q=.75)
IQR = data_kol['PROPERTYSQFT'].apply(stats.iqr)
data_kol = data_kol[~((data_kol['PROPERTYSQFT'] < (Q1-1.5*IQR)) | (data_kol['PROPERTYSQFT'] > (Q3+1.5*IQR)))]
print(data_kol)

print(data_kol.corr())
#После удаления выбросов коэффициент корреляции стал меньше
#Это говорит о уменьшении зависимости полей PRICE и PROPERTYSQFT с остальными количественными полями