import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

#Задание: Запустите ячейки ниже для импорта библиотек и загрузки данных из файла в датайфрейм Pandas.
data = pd.read_csv('CIA_Country_Facts.csv')

#Задание: посмотрите на строки и колонки в данных, в том числе на типы данных для колонок.
#ОТВЕТ: Первые два параметра Country и Region являются категориальными данными, а остальные количественные, а также отсутствует целевая переменная

#Давайте подготовим наши данные для кластеризации с помощью метода К-средних!

#Задание: Постройте отчёт - сколько строк имеют отсутствующие значения в той или иной колонке.

