import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.tree import plot_tree

#1
data = pd.read_csv('sonar_all-data.csv')

#2
X = data.drop('Label', axis=1)
y = data['Label']
print(y)
y = data['Label'].map({'R':0, 'M':1})
print(y)

#3
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)

#4
scaler = StandardScaler()
scaled_X_train = scaler.fit_transform(X_train)
scaled_X_test = scaler.transform(X_test)

#5
error = []
for i in range(1, 31):
    knn = KNeighborsClassifier(n_neighbors=i)
    knn.fit(scaled_X_train, y_train)
    i_pred = knn.predict(scaled_X_test)
    accuracy = accuracy_score(y_test, i_pred)
    error.append(1 - accuracy)

#6
plt.plot(range(1, 31), error, 'bx-')
plt.title('The Elbow Method using Error')
plt.xlabel('K Value')
plt.ylabel('Error')
plt.show()

#7
optimal_k = 3
knn_optimal = KNeighborsClassifier(n_neighbors=optimal_k)
knn_optimal.fit(scaled_X_train, y_train)
y_pred = knn_optimal.predict(scaled_X_test)

#8
print('knn методом логтя')
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

#9
knn = KNeighborsClassifier()
grid_param = {'n_neighbors': range(1, 31)}
grid_model = GridSearchCV(estimator=knn, param_grid=grid_param, scoring='accuracy', cv=5, verbose=2)
grid_model.fit(scaled_X_train, y_train)
print(grid_model.best_params_)

#10
grid_model_pred = grid_model.predict(scaled_X_test)

#11
print('knn методом оптимального значения')
print("Confusion Matrix:")
print(confusion_matrix(y_test, grid_model_pred))
print("\nClassification Report:")
print(classification_report(y_test, grid_model_pred))

#12
#Первая получилась более точной

#13
svm = SVC()
svm_params = {'C': range(1, 31), 'kernel': ['linear', 'poly', 'rbf', 'sigmoid']}
svm_grid = GridSearchCV(estimator=svm, param_grid=svm_params, scoring='accuracy', cv=5, verbose=2)
svm_grid.fit(scaled_X_train, y_train)
print(svm_grid.best_params_)

#14
#svm_best = SVC(**optimal_params_svm)
#svm_best.fit(scaled_X_train, y_train)
svm_pred = svm_grid.predict(scaled_X_test)

#15
print('svm методом оптимального значения')
print("Confusion Matrix:")
print(confusion_matrix(y_test, svm_pred))
print("\nClassification Report:")
print(classification_report(y_test, svm_pred))

#16
tree = DecisionTreeClassifier()

#17
tree.fit(scaled_X_train, y_train)
tree_pred = tree.predict(scaled_X_test)

#18
print('Дерево решений')
print("Confusion Matrix:")
print(confusion_matrix(y_test, tree_pred))
print("\nClassification Report:")
print(classification_report(y_test, tree_pred))

#19
plt.figure(figsize=(16, 12))
plot_tree(tree, feature_names=X.columns, filled=True)
plt.title("Графическое дерево решений")
plt.show()

#20
tree4 = DecisionTreeClassifier(max_depth=4)
tree4.fit(scaled_X_train, y_train)
tree4_pred = tree4.predict(scaled_X_test)
print('Дерево решений с глубиной 4')
print("Confusion Matrix:")
print(confusion_matrix(y_test, tree4_pred))
print("\nClassification Report:")
print(classification_report(y_test, tree4_pred))

#21
plt.figure(figsize=(16, 12))
plot_tree(tree4, feature_names=X.columns, filled=True)
plt.title("Графическое дерево решений")
plt.show()

