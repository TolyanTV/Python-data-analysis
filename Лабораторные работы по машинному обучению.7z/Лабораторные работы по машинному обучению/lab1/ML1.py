import pandas as pd
import numpy as np

np.random.seed(242)

tr_types = pd.read_csv('tr_types.csv', sep=';')

# Задание 1
print("Задание 1")
# 1)
print("1)")
sample_tr_types = tr_types.sample(100)
print(sample_tr_types)
# 2)
print("2)")
#print(sample_tr_types['tr_description'])
print("{:.2f}".format(sample_tr_types[sample_tr_types['tr_description'].str.lower().str.contains("плата")].size/200))

# Задание 2
print("Задание 2")
tr = pd.read_csv("transactions.csv", nrows= 1000000)
tr_type_frequency = tr['tr_type'].value_counts(normalize=True)
print(tr_type_frequency)
tr_type_frequency.index.tolist()
for i in range(5):
   print(tr_types[(tr_types['tr_type'] == tr_type_frequency.index.tolist()[i])][['tr_description']])

##################################      ФАЙЛА transactions.csv В РЕПОЗИТОРИИ НЕТУ
# Задание 3
print("Задание 3")
# 1)
print("1)")
tr = pd.read_csv("transactions.csv", nrows= 1000000)
imax_tr = tr.nlargest(1, 'amount')['customer_id']
max_tr = tr[(tr['customer_id'] == (int(imax_tr)))]
#print(max_tr)
# 2)
print("2)")
abs_tr = max_tr['amount'].abs().value_counts()
print(abs_tr)


# Задание 4
print("Задание 4")
# 1)
print("1)")
data_transactions1 = tr.drop(columns=["tr_datetime","mcc_code","tr_type","term_id"])
data_transactions1.groupby("customer_id").sum()
print(np.median(data_transactions1.groupby("customer_id").sum()))

# 2)
print("2)")
data_transactions2 = tr.drop(columns=["tr_datetime","mcc_code","tr_type"])
data_transactions3 = data_transactions2.dropna()
data_transactions3 = data_transactions3.drop(columns=["term_id"])
data_transactions3.groupby("customer_id").sum()
print(np.median(data_transactions3.groupby("customer_id").sum()))

# 3)
print("3)")
print(tr.sort_values('amount').drop_duplicates(['mcc_code', 'tr_type'], keep='last'))

# 4)
print("4)")
sa = tr.sort_values('amount').drop_duplicates(['mcc_code', 'tr_type'], keep='last')
sa = sa.drop(columns=["tr_datetime","mcc_code","tr_type","term_id"])
sa.groupby("customer_id").sum()
print(np.median(sa.groupby("customer_id").sum()))

# 5)
print("5)")
print("{:.2f}".format(np.ptp([np.median(data_transactions1.groupby("customer_id").sum()), np.median(data_transactions3.groupby("customer_id").sum()), np.median(sa.groupby("customer_id").sum())])))

# Считываем первые 100000 строк
tr = pd.read_csv("transactions.csv", nrows= 1000000)
mcc = pd.read_csv("tr_mcc_codes.csv",delimiter=";")
types = pd.read_csv("tr_types.csv",delimiter=";")
gender = pd.read_csv("gender_train.csv")

# Задание 5
print("Задание 5")
tr = tr.merge(gender, how='left', left_on='customer_id', right_on='customer_id').merge(types, how='inner', left_on='tr_type', right_on='tr_type').merge(mcc, how='inner', left_on='mcc_code', right_on='mcc_code')
print(tr)

# Задание 6
print("Задание 6")
print("{:.2f}".format(np.abs(tr[tr["gender"] == 1 ][ tr["amount"] <= 0]["amount"].mean() - tr[tr["gender"] == 0 ][ tr["amount"] <= 0]["amount"].mean())))

# Задание 7
print("Задание 7")
# 1)
tr["mcc+type"] = tr["mcc_code"].astype(str) + tr["tr_type"].astype(str)
# 2)
print("2)")
minus_tr = tr[tr["amount"] < 0]
print(minus_tr.groupby('mcc+type').agg({'amount': ['var', 'count']})['amount']['var'])
# 3)
print("3)")
ratio  = minus_tr.groupby('mcc+type').agg({'amount': ['var', 'count']})['amount']
ratio = ratio [ratio.apply(lambda x: x['count'] >= 10, axis=1)]
print("{:.0f}".format(ratio .describe()['var'].loc["max"]/ratio.describe()['var'].loc['min']))

# Задание 8
print("Задание 8")
# 1)
print("1)")
ratio_tr = tr[(tr['amount'] > 0)].sort_values(['gender', 'customer_id', 'amount'])
maxx_tr = ratio_tr.drop_duplicates(subset=['customer_id'], keep='last')
maxx_tr = maxx_tr.sort_values(['amount'])

# 2)
print("2)")
min_5_male = maxx_tr[maxx_tr['gender'] == 0].head(5)
print(min_5_male)
min_5_female = maxx_tr[maxx_tr['gender'] == 1].head(5)
print(min_5_female)

# 3)
print("3)")
print(set(min_5_male['tr_description']) & set(min_5_female['tr_description']))

