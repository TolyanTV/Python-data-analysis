import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import plot_tree


#4.Загрузить данные в датафрейм
data = pd.read_csv('banana_quality.csv')

#5.Вывести статистическую информацию о наборе данных
print(data.info())
print(data.describe())

#6.Вывести названия столбцов и строк
print(data.keys())
print(data.head(5))

#7.Заменить или удалить пропущенные значения
print(data.isnull().sum())
#Т.к. у нас нет пропущенных значение, то и удалять ничего не нужно

#8.Заменить категориальные данные количественными
data['Quality'] = data['Quality'].map({'Good': 1, 'Bad': 0})

#9.Выбрать важные признаки с помощью корреляционного анализа
table_corr = data.corr()
print(table_corr['Quality'].sort_values(ascending=False))
plt.figure(figsize=(15, 15))
sns.heatmap(table_corr, annot=True, fmt = '.4f')
plt.title("Корреляция между признаками", fontsize=16)
plt.show()

#11.Визуализировать данные с помощью Matplotlib и Seaborn
sns.pairplot(data, hue = 'Quality')
plt.show()

#12.Выбрать и обосновать выбор метрик
#Я решил выбрать точность, classification_report и confusion_matrix в качестве метрик, потому что точность и classification_report покажут нам долю верно предсказанных положительныхк классов, а также другие метрики и среднее
# confusion_matrix в целом покажет, сколько наблюдений было правильно и неправильно классифицированы

#КЛАССИФИКАЦИЯ

#13.Построить модели и обучить их
x = data.drop('Quality', axis=1)
y = data['Quality']
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)


scaler = StandardScaler()
scaled_X_train = scaler.fit_transform(x_train)
scaled_X_test = scaler.transform(x_test)
#
# Логистическая регрессия
param_grid_log_reg = {'C': [0.001, 0.01, 0.1, 1, 10, 100]}
model1 = LogisticRegression()
grid_search1 = GridSearchCV(estimator=model1, param_grid=param_grid_log_reg, scoring='accuracy', cv=5, verbose=2)
grid_search1.fit(scaled_X_train, y_train)
best_params1 = grid_search1.best_params_
print(best_params1)
optimal_model1 = LogisticRegression(**best_params1)
optimal_model1.fit(scaled_X_train, y_train)
y_pred1 = optimal_model1.predict(scaled_X_test)
accuracy1 = accuracy_score(y_test, y_pred1)
# 0.1

# Дерево решений
param_grid_tree = {'max_depth': np.arange(2, 15)}
model2 = DecisionTreeClassifier()
grid_search2 = GridSearchCV(estimator=model2, param_grid=param_grid_tree, scoring='accuracy', cv=5, verbose=2)
grid_search2.fit(scaled_X_train, y_train)
best_params2 = grid_search2.best_params_
print(best_params2)
optimal_model2 = DecisionTreeClassifier(**best_params2)
optimal_model2.fit(scaled_X_train, y_train)
y_pred2 = optimal_model2.predict(scaled_X_test)
accuracy2 = accuracy_score(y_test, y_pred2)
#{'max_depth': 11}

# Случайный лес
param_grid_rf = {'n_estimators': [100, 200, 300], 'max_depth': np.arange(2, 15)}
model3 = RandomForestClassifier()
grid_search3 = GridSearchCV(estimator=model3, param_grid=param_grid_rf, scoring='accuracy', cv=5, verbose=2)
grid_search3.fit(scaled_X_train, y_train)
best_params3 = grid_search3.best_params_
print(best_params3)
optimal_model3 = RandomForestClassifier(**best_params3)
optimal_model3.fit(scaled_X_train, y_train)
y_pred3 = optimal_model3.predict(scaled_X_test)
accuracy3 = accuracy_score(y_test, y_pred3)
# {'max_depth': 13, 'n_estimators': 100}

print(f"Accuracy logistic regression: {accuracy1}")
print(f"Accuracy tree: {accuracy2}")
print(f"Accuracy forest: {accuracy3}")
print(f"Classification Report logistic regression:\n{classification_report(y_test, y_pred1)}")
print(f"Classification Report tree:\n{classification_report(y_test, y_pred2)}")
print(f"Classification Report forest:\n{classification_report(y_test, y_pred3)}")
print(f"Confusion Matrix logistic regression:\n{confusion_matrix(y_test, y_pred1)}")
print(f"Confusion Matrix tree:\n{confusion_matrix(y_test, y_pred2)}")
print(f"Confusion Matrix forest:\n{confusion_matrix(y_test, y_pred3)}")
plt.figure(figsize=(16, 12))
plot_tree(optimal_model2, feature_names=x.columns, filled=True)
plt.title("Графическое дерево решений")
plt.show()

#КЛАСТЕРИЗАЦИЯ

from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.cluster import DBSCAN
from sklearn.neighbors import NearestNeighbors
import matplotlib.cm as cm

#Зададим количество кластеров
kmodel1 = KMeans(n_clusters=2, random_state=42)
label = kmodel1.fit_predict(x)
#silhouette_kmeans = silhouette_score(scaled_X_test, label)
print(set(list(label)))
print(pd.DataFrame(label).value_counts())
#Кластеры сбалансированы

#Диаграмма рассеивания
pca = PCA(n_components=2)
pca.fit(x)
x_pca = pca.transform(x)
filter_label0 = x_pca[label == 0]
filter_label1 = x_pca[label == 1]
plt.scatter(filter_label0[:,0], filter_label0[:,1], color = 'blue', s = 0.05)
plt.scatter(filter_label1[:,0], filter_label1[:,1], color = 'red', s = 0.05)
plt.show()

filter_label0 = np.array(x[label == 0][['Weight', 'Sweetness']])
filter_label1 = np.array(x[label == 1][['Weight', 'Sweetness']])
plt.xlabel('Weight')
plt.ylabel('Sweetness')
plt.scatter(filter_label0[:,0], filter_label0[:,1], color = 'blue', s = 0.05)
plt.scatter(filter_label1[:,0], filter_label1[:,1], color = 'red', s = 0.05)
plt.show()

#print('Silhouette Score:', silhouette_kmeans)


#DBSCAN

nn = NearestNeighbors(n_neighbors=11)
n = nn.fit(x)
distances, indices = n.kneighbors(x)
distances = np.sort(distances[:,10], axis=0)
plt.figure(figsize=(10, 10))
plt.plot(distances)
plt.xlabel('Points')
plt.ylabel('Distance')
plt.show()

dbmodel = DBSCAN(eps=3, min_samples=10)
dbpred = dbmodel.fit_predict(x)
print(set(list(label)))
print(pd.DataFrame(label).value_counts())

data1 = data[['Weight', 'Sweetness']]
data['label'] = label
fig = plt.figure(figsize=(10, 10))
sns.scatterplot(data=data1, x='Weight', y='Sweetness', hue=label, size=8)
plt.show()

filtered_label0 = x_pca[label == 0]
filtered_label1 = x_pca[label == -1]
plt.scatter(filtered_label0[:, 0], filtered_label0[:, 1], color='blue', s=0.05)
plt.scatter(filtered_label1[:, 0], filtered_label1[:, 1], color='red', s=0.05)
plt.show()






