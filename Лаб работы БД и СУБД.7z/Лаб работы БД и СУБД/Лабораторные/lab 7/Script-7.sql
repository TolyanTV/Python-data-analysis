-- неповторяемое чтение.
begin transaction isolation level read committed;
select price from products where name = 'Телефон';
select pg_sleep(7);
select price from products where name = 'Телефон';
commit; --видны зафиксированные изменения


--repeatable read (повторяемое чтение)
-- неповторяемое чтение. 
begin transaction isolation level repeatable read;
select price from products where name = 'Телефон';
select pg_sleep(7);
select price from products where name = 'Телефон';
commit; -- не видны изменения


-- фантомное чтение. 
begin transaction isolation level read committed;
select sum(price) from products;
select pg_sleep(7);
select sum(price) from products;
commit; -- видна вставка
-- read uncommitted (committed) (чтение незафиксированных данных)


--фантомное чтение. 
begin transaction isolation level repeatable read;
select sum(price) from products;
select pg_sleep(7);
select sum(price) from products;
commit; --не видна вставка


select * from products;
--другие аномалии. 
begin transaction isolation level repeatable read ;
insert into products (id, name, price, budget) select 5, 'product1', sum(price), 'Дешевый'
from products
where budget = 'Дорогой';
select pg_sleep(7);
commit; --транзакции зафиксируются, но полученный результат не соответствовал бы полученному порядку
--repeatable read (повторяемое чтение)

--serizable (аномалия сериализации)
--другие аномалии. 
begin transaction isolation level serializable;
insert into products (id, name, price, budget) select 7, 'product3', Sum(price), 'Дешевый'
from products
where budget = 'Дорогой';
select pg_sleep(7);
commit; -- результат параллельно выполняемых не согласовывается с результатом транзакций, выполняемых поочередно
--будет зафиксирована лишь одна транзакция,
-- а вторая закончится откатом с сообщением об ошибке
--serizable (аномалия сериализации)