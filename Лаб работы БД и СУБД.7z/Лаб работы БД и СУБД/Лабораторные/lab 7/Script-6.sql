create table products(
	id integer primary key,
	name varchar not null,
	price integer,
	budget  varchar
);

insert into products (id, name, price, budget) values (1, 'Телефон', 500, 'Дешевый');
insert into products (id, name, price, budget) values (2, 'Компьютер', 1000, 'Дешевый');

--Точка сохранения
begin;
select * from products;
savepoint point1;
insert into products (id, name, price, budget) values (10, 'Компьютер', 10000, 'Дорогой');
select * from products;
rollback to point1;
select * from products;
commit;

drop table products;
