-- неповторяемое чтение. 
begin transaction isolation level read committed;
update products set price = 1 where name = 'Телефон';
commit;

--repeatable read (повторяемое чтение)
-- неповторяемое чтение. 
begin transaction isolation level repeatable read;
update products set price = 400 where name = 'Телефон';
commit;

--фантомное чтение. 
begin transaction isolation level read committed;
insert into products (id, name, price, budget) values (3, 'Ноутбук', 1500, 'Дорогой');
commit;
-- read uncommitted (committed) (чтение незафиксированных данных)


--фантомное чтение. 
begin transaction isolation level repeatable read;
insert into products (id, name, price, budget) values (4, 'Планшет', 200, 'Дорогой');
commit;

--другие аномалии. 
begin transaction isolation level repeatable read;
insert into products (id, name, price, budget) select 6, 'product2', sum(price), 'Дорогой'
from products
where budget = 'Дешевый';
commit;
--repeatable read (повторяемое чтение)

--serizable (аномалия сериализации)
--другие аномалии. 
begin transaction isolation level serializable;
insert into products (id, name, price, budget) select 8, 'product4', sum(price), 'Дорогой'
from products
where budget = 'Дешевый';
commit;
--serizable (аномалия сериализации)
