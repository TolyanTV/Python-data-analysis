/*1. Создание спец. таблицы.*/
create table spec(
	id integer not null primary key,
	tableName varchar not null,
	columnName varchar not null,
	currmax integer
);

/*2. Добавление в спец. таблицу записи (1, spec, id, 1).*/
insert into spec (id, tableName, columnName, currmax) values (1, 'spec', 'id', 1);

/*3. Создание хранимой процедуры (ХП).*/
create or replace function XP(tableName1 varchar, columnName1 varchar, out nextNum integer)
language plpgsql
as $$
begin 
	update spec 
	set currmax = currmax + 1 /* значение инкрементируется */
	where tableName = tableName1 and columnName = columnName1 returning currmax into nextNum; /* если нашлась такая запись в спец.таблице */ /* значение возвращается пользователю */
	/* если такой записи нет */
	if (nextNum is null) then execute format ('select coalesce(max(%s) + 1, 1) from %s;', quote_ident(columnName1), quote_ident(tableName1)) into nextNum;
--ХП сперва ищет максимальное число в столбце в запрашиваемой таблице, записывает новую строку, содержащую следующее за найденным число, в спец. таблицу и возвращает это значение пользователю. 
--При отсутствии значений в запрашиваемой таблице, пользователю возвращается 1, и этот же результат записывается в спец. таблицу
		insert into spec (id, tableName, columnName, currmax) values (XP('spec', 'id'), tableName1, columnName1, nextNum);
	end if;
end;
$$;

/*4. Вызов вашей ХП с параметрами 'spec', 'id'. Функция должна вернуть `2`.*/
select XP('spec', 'id');

/*5. Распечатка содержимого спец. таблицы. Должна быть 1 строка "(1, spec, id, 2)".*/
select * from spec;

/*6. Вызов вашей ХП с параметрами 'spec', 'id'. Функция должна вернуть `3`.*/
select XP('spec', 'id');

/*7. Распечатка содержимого спец. таблицы. Должна быть 1 строка "(1, spec, id, 3)".*/
select * from spec;

/*8. Создание новой таблицы с одним столбцом 'id'. Назовём её test.*/
create table test(
	id integer not null primary key
);

/*9. Добавление в таблицу test записи (10).*/
insert into test(id) values(10);

/*10. Вызов вашей ХП с параметрами 'test', 'id'. Функция должна вернуть `11`.*/
select XP('test', 'id');

/*11. Распечатка содержимого спец. таблицы. Должно быть 2 строки "(1, spec, id, 4)" "(4, test, id, 11)".*/
select * from spec;

/*12. Вызов вашей ХП с параметрами 'test', 'id'. Функция должна вернуть `12`.*/
select XP('test', 'id');

/*13. Распечатка содержимого спец. таблицы. Должно быть 2 строки "(1, spec, id, 4)" "(4, test, id, 12)".*/
select * from spec;

/*14. Создание таблицы 'test2' со столбцами 'num_value1', 'num_value2'.*/
create table test2(
	num_value1 integer,
	num_value2 integer
);

/*15. Вызов вашей ХП с параметрами 'test2', 'num_value1'. Функция должна вернуть `1`.*/
select XP('test2', 'num_value1');

/*16. Распечатка содержимого спец. таблицы. Должно быть 3 строки "(1, spec, id, 5)" "(4, test, id, 12), (5, test2, num_value1, 1)".*/
select * from spec;

/*17. Вызов вашей ХП с параметрами 'test2', 'num_value1'. Функция должна вернуть `2`.*/
select XP('test2', 'num_value1');

/*18. Распечатка содержимого спец. таблицы. Должно быть 3 строки "(1, spec, id, 5)" "(4, test, id, 12), (5, test2, num_value1, 2)".*/
select * from spec;

/*19. Добавление в таблицу 'test2'(num_value1, num_value2) записи (2, 13).*/
insert into test2(num_value1, num_value2) values (2, 13);

/*20. Вызов вашей ХП с параметрами 'test2', 'num_value2'. Функция должна вернуть `14`.*/
select XP('test2', 'num_value2');

/*21. Распечатка содержимого спец. таблицы. Должно быть 4 строки "(1, spec, id, 6)" "(4, test, id, 12), (5, test2, num_value1, 2), (6, test2, num_value2, 14)".*/
select * from spec;

/*22. Вызов вашей ХП с параметрами 'test2', 'num_value1' 5 раз.*/
select XP('test2', 'num_value1');
select XP('test2', 'num_value1');
select XP('test2', 'num_value1');
select XP('test2', 'num_value1');
select XP('test2', 'num_value1');

/*23. Распечатка содержимого спец. таблицы. Должно быть 4 строки "(1, spec, id, 6)" "(4, test, id, 12), (5, test2, num_value1, 7), (6, test2, num_value2, 14)".*/
select * from spec;

/*24. Удаление ХП.*/
drop function XP;

/*25. Удаление таблиц.*/
drop table spec;
drop table test;
drop table test2;



