SET plpgsql.extra_errors TO 'all';

create user teacher;
create user student;

create table users(
	id_user integer not null primary key generated always as identity,
	first_name varchar not null,
	second_name varchar not null,
	password varchar not null
);

create table journal(
	id_group integer not null primary key generated always as identity,
	nameGroup varchar not null,
	course integer not null
);

create table estimations(
	id_e integer primary key generated always as identity,
	id_user integer not null,
	id_group integer not null,
	estimation varchar not null,
	foreign key (id_user) references users(id_user),
	foreign key (id_group) references journal(id_group)
);

grant all privileges on database pravodostup to teacher;
grant all privileges on schema public to teacher;

alter table users enable row level security; -- накладываем запрет на просмотр всех строк

create policy teacher_access --разрешаем просмотр каких-то строк определенным ролям
	on users to teacher 
	using (second_name in (select second_name));

create policy student_access 
	on users to student 
	using (second_name in (select second_name where id_user <> 1));

alter table estimations enable row level security;

create policy _insert 
	on estimations for insert with check(id_user in (select id_user from users where /*lower(second_name) = user or*/ user = 'postanogov'));
create policy _update
	on estimations for update using (id_user in (select id_user from users where user = 'postanogov'));
create policy _select
	on estimations for select using (id_user in (select id_user from users where lower(second_name) = user or user = 'postanogov'));
																				-- имя переведенное в нижний регистр, потому что user 
grant all on users, journal, estimations to teacher;

--grant insert (first_name, second_name, password) on users to student;
--grant insert (nameGroup, course) on journal to student;
--grant insert (id_user, id_group, estimation) on estimations to student;
--grant update 
grant select (id_user, first_name, second_name) on users to student;--?????
grant select (nameGroup, course) on journal to student;--?????
grant select (id_user, id_group, estimation) on estimations to student;--?????

--grant all privileges on sequence id_user, id_journal, id_estimations to student; 

insert into users (first_name, second_name, password) values ('Игорь', 'Postanogov', 'password'); 
create user Postanogov; 
grant teacher to Postanogov; -- даем роль
insert into users (first_name, second_name, password) values ('Иван', 'Ivanov','13579'); 
create user Ivanov; 
grant student to Ivanov;
insert into users (first_name, second_name, password) values ('Петр', 'Petrov','24680'); 
create user Petrov; 
grant student to Petrov;
insert into users (first_name, second_name, password) values ('Сидор', 'Sidorov','12345'); 
create user Sidorov; 
grant student to Sidorov;


set role Postanogov;
insert into journal (nameGroup, course) values ('ПМИ-1,2', 3);
insert into estimations (id_user, id_group, estimation) values (2, 1, 'Оценка 5');

insert into journal (nameGroup, course) values ('ПМИ-3,4', 3);
insert into estimations (id_user, id_group, estimation) values (3, 2, 'Оценка 4');

insert into journal (nameGroup, course) values ('ПМИ-5,6', 3);
insert into estimations (id_user, id_group, estimation) values (4, 3, 'Оценка 3');
--update estimations set estimation = 'Оценка 5+' where id_user = 2 and estimation = 'Двойка!';
select * from users;
select * from estimations;
select * from journal;

set role Ivanov;
select first_name, second_name from users;
select id_user, id_group, estimation from estimations;
insert into journal (nameGroup, course) values ('ПМИ-1,2', 3); -- не работает
insert into estimations (id_user, id_group, estimation) values (2, 1, 'Оценка 5'); -- не работает


set role Petrov;
/*не можем сделать update потому что студен не может менять*/
select first_name, second_name from users;
select id_user, id_group, estimation from estimations;
insert into journal (nameGroup, course) values ('ПМИ-3,4','3');
--insert into estimations (id_user, id_group, estimation) values (2, 1, 'Оценка 4');
insert into estimations (id_user, id_group, estimation) values (3, 1, 'Оценка 4');


set role Sidorov;
select nameGroup from journal;
select estimation from estimations;
insert into journal (nameGroup, course) values ('ПМИ-5,6','3');
--insert into estimations (id_user, id_group, estimation) values (4, 2, 'Оценка 3');??????????
insert into estimations (id_user, id_group, estimation) values (4, 1, 'Оценка 3');


reset role;

drop table estimations;
drop table journal;
drop table users;

drop role student;
revoke all privileges on database pravodostup from teacher;
revoke all privileges on schema public from teacher;
drop role teacher;
drop role Postanogov;
drop role Ivanov;
drop role Petrov;
drop role Sidorov;


