--
-- PostgreSQL database dump
--

-- Dumped from database version 10.23
-- Dumped by pg_dump version 10.23

-- Started on 2023-12-12 21:01:40

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 196 (class 1259 OID 24727)
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id integer NOT NULL,
    name character varying,
    surname character varying,
    email character varying
);



--
-- TOC entry 197 (class 1259 OID 24735)
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    id_clients integer NOT NULL,
    number character varying
);


--
-- TOC entry 198 (class 1259 OID 24748)
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id integer NOT NULL,
    id_order integer NOT NULL,
    product_name character varying,
    price character varying
);



--
-- TOC entry 2808 (class 0 OID 24727)
-- Dependencies: 196
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, name, surname, email) FROM stdin;
1	Карина	Азматова	karina8836
2	Анатолий	Андрюков	aai2003
3	Максим	Гладков	dertarus3222
4	Алексей	Зарехта	lksmlbx
\.


--
-- TOC entry 2809 (class 0 OID 24735)
-- Dependencies: 197
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, id_clients, number) FROM stdin;
1	1	152
2	2	287
3	3	28
4	4	119
5	1	191
\.


--
-- TOC entry 2810 (class 0 OID 24748)
-- Dependencies: 198
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, id_order, product_name, price) FROM stdin;
1	1	iPhone15	119990
2	2	iPhone15ProMax	194990
3	3	AppleWatchUltra	89990
4	4	iPhone14Plus	139990
5	5	AirPods	14990
6	2	iPadPro	116990
7	4	iMac	199990
\.


--
-- TOC entry 2680 (class 2606 OID 24734)
-- Name: clients clients_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pk PRIMARY KEY (id);


--
-- TOC entry 2682 (class 2606 OID 24742)
-- Name: orders orders_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pk PRIMARY KEY (id);


--
-- TOC entry 2684 (class 2606 OID 24755)
-- Name: products products_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pk PRIMARY KEY (id);


--
-- TOC entry 2685 (class 2606 OID 24743)
-- Name: orders orders_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_fk FOREIGN KEY (id_clients) REFERENCES public.clients(id);


--
-- TOC entry 2686 (class 2606 OID 24756)
-- Name: products products_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_fk FOREIGN KEY (id_order) REFERENCES public.orders(id);


-- Completed on 2023-12-12 21:01:40

--
-- PostgreSQL database dump complete
--

