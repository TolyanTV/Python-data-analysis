SET plpgsql.extra_errors TO 'all';

create table students(
	id_student integer primary key generated always as identity,
	first_name text not null,
	second_name text not null, 
	univer text not null
);

create table companies(
	id_company integer primary key generated always as identity,
	company_name text not null,
	num_of_vac integer
);

create table jobs(
	id_student integer,
	id_company integer, 
	get_job bool,
	foreign key (id_student) references students(id_student),
	foreign key (id_company) references companies(id_company),
	primary key(id_student, id_company)
);

--представление
create view my_view as
select first_name, second_name, univer, company_name, num_of_vac, get_job
from students
join jobs on jobs.id_student = students.id_student
join companies on companies.id_company = jobs.id_company;

create or replace function _insert() returns trigger 
language plpgsql
as $$
declare 
	id_student1 integer;
	id_company1 integer;
begin
	select id_student from students where first_name = new.first_name and second_name = new.second_name and univer = new.univer into id_student1; -- есть ли такой студент    
	if (id_student1 is null) then  -- если нет добавляем
		insert into students (first_name, second_name, univer) values (new.first_name, new.second_name, new.univer) returning id_student into id_student1;
	end if;
	select id_company from companies where company_name = new.company_name and num_of_vac = new.num_of_vac into id_company1;
	if (id_company1 is null) then
		insert into companies (company_name, num_of_vac) values (new.company_name, new.num_of_vac) returning id_company into id_company1;
	end if;
	insert into jobs (id_student, id_company, get_job) values (id_student1, id_company1, new.get_job);
	return new;
end;
$$;

create trigger _ins
instead of insert on my_view for each row execute /*function*/procedure _insert();	
--??????????????procedure

create or replace function _update() returns trigger 
language plpgsql
as $$
begin
	update jobs
	set get_job = new.get_job
	where id_student in (select id_student from students where first_name = new.first_name and second_name = new.second_name and univer = new.univer)
	and id_company in (select id_company from companies where company_name = new.company_name and num_of_vac = new.num_of_vac);
	return new;
end;
$$;

create trigger _upd
instead of update on my_view for each row execute procedure _update();
--??????????????procedure

create or replace function _delete() returns trigger 
language plpgsql
as $$
begin
	delete from jobs 
	where id_student in (select id_student from students where univer = new.univer)
	and id_company in (select id_company from company where company_name = new.company_name and num_of_vac = new.num_of_vac);
end;
$$;

create trigger _del
instead of delete on my_view for each row execute procedure _delete();
--??????????????procedure

insert into my_view (first_name, second_name, univer, company_name, num_of_vac, get_job) values ('Иван', 'Иванов', 'ПГУ', 'Yandex', 5, true);
insert into my_view (first_name, second_name, univer, company_name, num_of_vac, get_job) values ('Петр', 'Петров', 'ПГУ', 'Контур', 7, true);
insert into my_view (first_name, second_name, univer, company_name, num_of_vac, get_job) values ('Сидор', 'Сидоров', 'ПГУ', 'Тинькофф', 2, false);

select * from students;
select * from companies;
select * from jobs;
select * from my_view;

update companies set company_name = 'Сбербанк' where company_name = 'Тинькофф'; 
select * from companies; --???
--select * from jobs;
--select * from my_view;

delete from jobs where get_job = false;
--select * from my_view;
--select * from jobs;
select * from students;
select * from companies;
select * from jobs;
select * from my_view;

drop view my_view;

drop table jobs cascade;
drop table students cascade;
drop table companies cascade;

drop function _insert;
drop function _update;
drop function _delete;



